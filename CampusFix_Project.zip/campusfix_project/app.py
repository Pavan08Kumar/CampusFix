from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("campusfix.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS issues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                location TEXT NOT NULL,
                description TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def index():
    with get_db() as db:
        issues = db.execute("SELECT * FROM issues ORDER BY id DESC").fetchall()
        total = db.execute("SELECT COUNT(*) FROM issues").fetchone()[0]
        open_count = db.execute("SELECT COUNT(*) FROM issues WHERE status='Open'").fetchone()[0]
        progress_count = db.execute("SELECT COUNT(*) FROM issues WHERE status='In Progress'").fetchone()[0]
        resolved_count = db.execute("SELECT COUNT(*) FROM issues WHERE status='Resolved'").fetchone()[0]
    return render_template("index.html", issues=issues, total=total,
        open_count=open_count, progress_count=progress_count, resolved_count=resolved_count)

@app.route("/report", methods=["POST"])
def report():
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "").strip()
    location = request.form.get("location", "").strip()
    description = request.form.get("description", "").strip()
    if not all([title, category, location, description]):
        flash("Please complete every field.")
        return redirect(url_for("index"))
    with get_db() as db:
        db.execute("INSERT INTO issues (title, category, location, description) VALUES (?, ?, ?, ?)",
                   (title, category, location, description))
    flash("Issue reported successfully.")
    return redirect(url_for("index"))

@app.route("/status/<int:issue_id>", methods=["POST"])
def update_status(issue_id):
    status = request.form.get("status")
    if status not in {"Open", "In Progress", "Resolved"}:
        flash("Invalid status.")
    else:
        with get_db() as db:
            db.execute("UPDATE issues SET status=? WHERE id=?", (status, issue_id))
        flash("Status updated.")
    return redirect(url_for("index"))

@app.route("/delete/<int:issue_id>", methods=["POST"])
def delete_issue(issue_id):
    with get_db() as db:
        db.execute("DELETE FROM issues WHERE id=?", (issue_id,))
    flash("Report deleted.")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
