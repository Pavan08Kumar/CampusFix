# CampusFix — Campus Issue Tracker

A small Flask + SQLite prototype that lets students submit campus issues and track their status.

## Features
- Submit a report with title, category, location and description
- View all reports in a shared register
- Update status: Open, In Progress or Resolved
- Dashboard counts for each status
- Delete test reports
- SQLite storage; parameterized SQL queries

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended).
4. Run `pip install -r requirements.txt`.
5. Run `python app.py`.
6. Open http://127.0.0.1:5000

The database is created automatically on first run.

## Before publishing
This is a learning prototype, not a production campus service. Add authentication, role-based permissions, CSRF protection, input moderation, backups, HTTPS and deployment environment variables before real use. Change `app.secret_key` before deployment. Do not enter private student information.

## Suggested next improvements
- Student/admin accounts
- Search and category filters
- Image attachments
- Email notifications
- Analytics by category and resolution time

## Tech
Python, Flask, SQLite, HTML, CSS.
